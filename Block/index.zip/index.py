import logging
import boto3
from botocore.exceptions import ClientError
import json

AWS_REGION = 'cn-north-1'
rulelist=[]
# logger config
logger = logging.getLogger()
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s: %(levelname)s: %(message)s')

vpc_client = boto3.client("ec2", region_name=AWS_REGION)

def lambda_handler(event, context):
    # 解析securityhub到来的finding,取出相应字段
    a='执行成功'
    infor=event['detail']['findings'][0]["ProductFields"]
    ip=infor["aws/guardduty/service/action/networkConnectionAction/remoteIpDetails/ipAddressV4"]
    cidr=ip+'/32'
 
    SubnetId=event['detail']['findings'][0]['Resources'][0]["Details"]['AwsEc2Instance']['SubnetId']
    
    naclinfo = vpc_client.describe_network_acls(Filters=
    [
        {
            'Name': 'association.subnet-id',
            'Values':[SubnetId]
        }
    ])
    
    nacl_id=naclinfo['NetworkAcls'][0]['NetworkAclId']
    temp=naclinfo['NetworkAcls'][0]['Entries']
    print(temp)
    for each in temp:
        rulelist.append(each['RuleNumber'])
    print(rulelist)
    rule_number=min(rulelist)-1
    print(rule_number,SubnetId)

    try:
        response = vpc_client.create_network_acl_entry(CidrBlock=cidr,
                                                       Egress=False,
                                                       NetworkAclId=nacl_id,
                                                       PortRange={
                                                           'From': 22,
                                                           'To': 22,
                                                       },
                                                       Protocol='6',
                                                       RuleAction='deny',
                                                       RuleNumber=rule_number)
    except ClientError:
        logger.exception('Could not create a network acl entry.')
        raise
    else:
        return (cidr+' has been blocked by our Network ACL for subnet '+SubnetId)
  
